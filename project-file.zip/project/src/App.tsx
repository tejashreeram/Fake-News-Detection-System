import React from 'react';
import NewsAnalyzer from './components/NewsAnalyzer';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <NewsAnalyzer />
    </div>
  );
}

export default App;