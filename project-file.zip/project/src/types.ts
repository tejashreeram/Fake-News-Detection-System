export interface NewsAnalysis {
  text: string;
  prediction: 'real' | 'fake';
  confidence: number;
  features: {
    sentiment: number;
    clickbaitScore: number;
    emotionalTone: number;
    sourceCredibility: number;
    factualConsistency: number;
    citationScore: number;
    verifiableClaims: number;
  };
}

export interface AnalysisResult {
  isReal: boolean;
  confidence: number;
  features: {
    sentiment: number;
    clickbaitScore: number;
    emotionalTone: number;
    sourceCredibility: number;
    factualConsistency: number;
    citationScore: number;
    verifiableClaims: number;
  };
  factChecking: {
    verifiedClaims: string[];
    suspiciousClaims: string[];
    missingContext: string[];
  };
}