import React, { useState } from 'react';
import { AlertTriangle, CheckCircle, BarChart3, Brain, Search, Shield, AlertCircle } from 'lucide-react';
import type { AnalysisResult } from '../types';

// Simulated ML analysis (in real-world, this would call an API)
const analyzeText = async (text: string): Promise<AnalysisResult> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // Enhanced heuristics for demo
  const hasClickbaitWords = /(shocking|unbelievable|you won't believe|mind-blowing)/i.test(text);
  const hasEmotionalWords = /(outrage|scandal|terrible|amazing)/i.test(text);
  const hasCredibleSourceMarkers = /(according to|researchers|study|experts|published|reported)/i.test(text);
  const hasCitations = /(cited|quoted|stated by|confirmed by|verified by)/i.test(text);
  const hasNumbers = /\d+%|\d+ percent|\d+ people|\d+ cases/i.test(text);
  const hasVerifiableClaims = /(found that|discovered|concluded|confirmed|proven)/i.test(text);
  
  const clickbaitScore = hasClickbaitWords ? 0.8 : 0.2;
  const emotionalTone = hasEmotionalWords ? 0.7 : 0.3;
  const sourceCredibility = hasCredibleSourceMarkers ? 0.8 : 0.4;
  const factualConsistency = hasNumbers ? 0.7 : 0.4;
  const citationScore = hasCitations ? 0.8 : 0.3;
  const verifiableClaims = hasVerifiableClaims ? 0.7 : 0.4;
  const sentiment = Math.random();
  
  // Enhanced scoring algorithm
  const score = (
    (1 - clickbaitScore) * 0.15 +
    (1 - emotionalTone) * 0.15 +
    sourceCredibility * 0.2 +
    factualConsistency * 0.2 +
    citationScore * 0.15 +
    verifiableClaims * 0.15
  );

  // Extract potential claims for fact-checking
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const verifiedClaims = sentences
    .filter(s => hasCredibleSourceMarkers && (hasNumbers || hasCitations))
    .slice(0, 2);
  const suspiciousClaims = sentences
    .filter(s => hasClickbaitWords || (hasEmotionalWords && !hasCredibleSourceMarkers))
    .slice(0, 2);
  const missingContext = sentences
    .filter(s => !hasCredibleSourceMarkers && hasNumbers)
    .slice(0, 2);

  return {
    isReal: score > 0.5,
    confidence: Math.round(Math.abs(score - 0.5) * 2 * 100),
    features: {
      sentiment,
      clickbaitScore,
      emotionalTone,
      sourceCredibility,
      factualConsistency,
      citationScore,
      verifiableClaims
    },
    factChecking: {
      verifiedClaims,
      suspiciousClaims,
      missingContext
    }
  };
};

const FeatureBar: React.FC<{ value: number; label: string }> = ({ value, label }) => (
  <div className="mb-4">
    <div className="flex justify-between mb-1">
      <span className="text-sm font-medium text-gray-700">{label}</span>
      <span className="text-sm font-medium text-gray-700">{Math.round(value * 100)}%</span>
    </div>
    <div className="w-full bg-gray-200 rounded-full h-2">
      <div
        className={`h-2 rounded-full transition-all duration-500 ${
          value > 0.7 ? 'bg-green-600' : value > 0.4 ? 'bg-yellow-500' : 'bg-red-500'
        }`}
        style={{ width: `${value * 100}%` }}
      />
    </div>
  </div>
);

const ClaimsList: React.FC<{
  claims: string[];
  type: 'verified' | 'suspicious' | 'missing';
  title: string;
}> = ({ claims, type, title }) => {
  if (claims.length === 0) return null;

  return (
    <div className="mb-4">
      <div className="flex items-center mb-2">
        {type === 'verified' && <CheckCircle className="w-5 h-5 text-green-500 mr-2" />}
        {type === 'suspicious' && <AlertTriangle className="w-5 h-5 text-red-500 mr-2" />}
        {type === 'missing' && <AlertCircle className="w-5 h-5 text-yellow-500 mr-2" />}
        <h4 className="text-md font-medium">{title}</h4>
      </div>
      <ul className="list-disc list-inside pl-7 space-y-1">
        {claims.map((claim, index) => (
          <li key={index} className="text-sm text-gray-700">{claim.trim()}</li>
        ))}
      </ul>
    </div>
  );
};

export default function NewsAnalyzer() {
  const [text, setText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const handleAnalyze = async () => {
    if (!text.trim()) return;
    
    setIsAnalyzing(true);
    try {
      const analysis = await analyzeText(text);
      setResult(analysis);
    } catch (error) {
      console.error('Analysis failed:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex items-center justify-center mb-8">
        <Shield className="w-8 h-8 text-blue-600 mr-2" />
        <h1 className="text-3xl font-bold text-gray-900">AI Fact Checker</h1>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
        <textarea
          className="w-full h-32 p-4 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="Paste news article text here for fact-checking analysis..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <button
          className={`mt-4 px-6 py-2 rounded-lg text-white font-medium flex items-center justify-center ${
            isAnalyzing
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700'
          }`}
          onClick={handleAnalyze}
          disabled={isAnalyzing || !text.trim()}
        >
          {isAnalyzing ? (
            <>Analyzing...</>
          ) : (
            <>
              <Search className="w-5 h-5 mr-2" />
              Analyze Text
            </>
          )}
        </button>
      </div>

      {result && (
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center mb-6">
            {result.isReal ? (
              <CheckCircle className="w-8 h-8 text-green-500 mr-2" />
            ) : (
              <AlertTriangle className="w-8 h-8 text-red-500 mr-2" />
            )}
            <h2 className="text-2xl font-semibold">
              {result.isReal ? 'High Factual Accuracy' : 'Low Factual Accuracy'}
            </h2>
          </div>

          <div className="mb-6">
            <div className="flex items-center mb-2">
              <BarChart3 className="w-5 h-5 text-gray-600 mr-2" />
              <h3 className="text-lg font-medium">Confidence Score: {result.confidence}%</h3>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-lg font-medium mb-4">Fact-Checking Analysis:</h3>
            <div className="space-y-4">
              <FeatureBar
                label="Source Credibility"
                value={result.features.sourceCredibility}
              />
              <FeatureBar
                label="Factual Consistency"
                value={result.features.factualConsistency}
              />
              <FeatureBar
                label="Citation Score"
                value={result.features.citationScore}
              />
              <FeatureBar
                label="Verifiable Claims"
                value={result.features.verifiableClaims}
              />
              <FeatureBar
                label="Emotional Tone"
                value={result.features.emotionalTone}
              />
              <FeatureBar
                label="Clickbait Score"
                value={result.features.clickbaitScore}
              />
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-medium mb-4">Detailed Analysis:</h3>
            <ClaimsList
              claims={result.factChecking.verifiedClaims}
              type="verified"
              title="Verified Claims"
            />
            <ClaimsList
              claims={result.factChecking.suspiciousClaims}
              type="suspicious"
              title="Suspicious Claims"
            />
            <ClaimsList
              claims={result.factChecking.missingContext}
              type="missing"
              title="Claims Needing Context"
            />
          </div>
        </div>
      )}
    </div>
  );
}